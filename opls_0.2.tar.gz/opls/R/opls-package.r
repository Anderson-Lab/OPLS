#' opls.
#'
#' @name opls
#' @docType package
NULL
